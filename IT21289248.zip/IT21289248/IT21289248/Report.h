#pragma once
#include"Order.h"
class Report
{
private:
	char R_id[30];
	char Description[100];
	char Date[10];
	char Time[8];
	Order* od;
public:
	Report();
	void SetReport(const char rid[], const char Des[], const char date[], const char time[]);
	double RetrieveReport();
	~Report();

};

