#include "Order.h"
#include<iostream>
#include<cstring>
using namespace std;
Order::Order()
{
	strcpy_s(C_id, "C001");
	strcpy_s(Date, "01.01.2022");
	strcpy_s(Time, "01:10:50");
	Price = 0.00;

}

void Order::StoreOrderDetails(const char Cid[], char date[], const char time[], double price)
{
	strcpy_s(C_id,Cid);
	strcpy_s(Date,date);
	strcpy_s(Time,time);
	Price = price;
}

double Order::RetrieveFoodItem()
{
	return 0.0;
}

Order::~Order()
{
	cout << "Destructor is called." << endl;
}
