#pragma once
#include"Customer.h"
class Feedback
{
private:
	char F_id[3];
	char Description[100];
	int rate;
	char Date[10];
	char Time[8];
public:
	Feedback();
	void SetFeedback(const char fid[],const char Des[],int rate,const char date[],const char time[],Customer*c);
	void RetrieveFeedback();
	~Feedback();

};

