#pragma once
#include"Payment.h"
#include"Customer.h"
#include"Chef.h"
class Order
{
protected:
	char C_id[3];
	char Date[10];
	char Time[8];
	double Price;
	Payment* pay;
	Customer* cu;
	Chef* ch;
public:
	Order();
	void StoreOrderDetails(const char Cid[],char date[],const char time[],double price);
	double RetrieveFoodItem();
	~Order();
};

