#include "Feedback.h"
#include<iostream>
#include<cstring>
using namespace std;
Feedback::Feedback()
{
	strcpy_s(F_id, "F001");
	strcpy_s(Description, "");
	rate = 0;
	strcpy_s(Date, "01.01.2022");
	strcpy_s(Time, "01.10.50");
}

void Feedback::SetFeedback(const char fid[], const char Des[], int rate, const char date[], const char time[],Customer*c)
{
	strcpy_s(F_id,fid);
	strcpy_s(Description,Des);
	rate = 0;
	strcpy_s(Date, date);
	strcpy_s(Time,time);
}

void Feedback::RetrieveFeedback()
{
}

Feedback::~Feedback()
{
	cout << "Destructor is called." << endl;
}
