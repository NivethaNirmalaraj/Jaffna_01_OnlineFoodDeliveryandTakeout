#include "Report.h"
#include<iostream>
#include<cstring>
using namespace std;
Report::Report()
{
	strcpy_s(R_id, "F001");
	strcpy_s(Description, "");
	strcpy_s(Date, "01.12.2022");
	strcpy_s(Time, "12.10.50");
}

void Report::SetReport(const char rid[], const char Des[], const char date[], const char time[])
{
	strcpy_s(R_id, rid);
	strcpy_s(Description, Des);
	strcpy_s(Date, date);
	strcpy_s(Time, time);
}

double Report::RetrieveReport()
{
	return 0.0;
}

Report::~Report()
{
	cout << "Destructor is called." << endl;
}
